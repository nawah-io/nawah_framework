from nawah.classes import L10N

# Add your app locale term here as L10N object. Learn more at: https://github.com/nawah-io/nawah_docs
